<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Fasilitas;
use App\Models\Inspeksi;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $totalFasilitas = Fasilitas::count();
        $inspeksiHariIni = Inspeksi::whereDate('tanggal_inspeksi', Carbon::today())->count();
        
        // Dapatkan fasilitas dengan status terakhir
        $fasilitas = Fasilitas::with('latestInspeksi')->get();

        $statusCount = [
            'bersih' => 0,
            'perlu_perhatian' => 0,
            'perlu_dibersihkan' => 0,
            'buruk' => 0,
            'belum_diinspeksi' => 0
        ];

        $fasilitasBurukCount = 0;
        $fasilitasTindakLanjut = [];

        foreach ($fasilitas as $item) {
            $lastInspeksi = $item->latestInspeksi;
            if ($lastInspeksi) {
                $kebersihan = strtolower($lastInspeksi->kondisi_kebersihan);
                $status = 'perlu_perhatian';

                if ($kebersihan == 'baik' && $lastInspeksi->ketersediaan_air == 'Ada' && $lastInspeksi->ketersediaan_sabun == 'Ada' && $lastInspeksi->bau_tidak_sedap == 'Tidak') {
                    $status = 'bersih';
                } elseif ($kebersihan == 'buruk' || $lastInspeksi->ketersediaan_air == 'Tidak Ada' || $lastInspeksi->bau_tidak_sedap == 'Ya') {
                    $status = 'buruk';
                    $fasilitasBurukCount++;
                } elseif ($kebersihan == 'cukup') {
                    $status = 'perlu_dibersihkan';
                } else {
                    $status = 'perlu_perhatian';
                }

                $statusCount[$status]++;

                if ($status != 'bersih') {
                    $item->status_badge = $status;
                    $fasilitasTindakLanjut[] = $item;
                }
            } else {
                $statusCount['belum_diinspeksi']++;
                $item->status_badge = 'belum_diinspeksi';
                $fasilitasTindakLanjut[] = $item;
            }
        }

        // Ambil 5 teratas
        $fasilitasTindakLanjut = array_slice($fasilitasTindakLanjut, 0, 5);

        // Grafik Line: 7 hari terakhir
        $last7Days = [];
        $inspeksiCounts = [];
        for ($i = 6; $i >= 0; $i--) {
            $date = Carbon::today()->subDays($i);
            $last7Days[] = $date->format('d M');
            $inspeksiCounts[] = Inspeksi::whereDate('tanggal_inspeksi', $date)->count();
        }

        // Fasilitas dengan masalah terbanyak (Buruk atau Cukup)
        $masalahTerbanyak = Inspeksi::select('fasilitas_id', DB::raw('count(*) as total'))
            ->whereIn('kondisi_kebersihan', ['Buruk', 'Cukup'])
            ->groupBy('fasilitas_id')
            ->orderBy('total', 'desc')
            ->limit(4)
            ->with('fasilitas')
            ->get();

        // Aktivitas Terbaru (Jadwal)
        $aktivitasTerbaru = \App\Models\Jadwal::with(['petugas', 'fasilitas'])
            ->orderBy('updated_at', 'desc')
            ->take(5)
            ->get();

        return view('admin.dashboard', compact(
            'totalFasilitas',
            'inspeksiHariIni',
            'fasilitasBurukCount',
            'statusCount',
            'fasilitasTindakLanjut',
            'last7Days',
            'inspeksiCounts',
            'masalahTerbanyak',
            'aktivitasTerbaru'
        ));
    }
}
